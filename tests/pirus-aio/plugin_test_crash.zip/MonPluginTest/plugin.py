import time
import random

class PirusPlugin(object):

    def run(self, config):
        self.notify(0, "Coussin trouvé")
        total = random.randrange(5,20)
        for i in range(1,total):
        	time.sleep(2)
        	self.notify(i, "zzz (Crash C-" + str(total-i) + ")")
        raise Exception('Erreur mon coussin est percé !! Je ne peux plus dormir')

    def notify(self, percent, infos):
        print(str(percent) + "%", infos) 





if __name__ == '__main__':
	test = PirusPlugin()
	test.run(None)