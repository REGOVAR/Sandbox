import time

class PirusPlugin(object):

    def run(self, config):
        self.notify(0, "Coussin trouvé")
        for i in range(1,100):
        	time.sleep(2)
        	self.notify(i, "zzz")
        self.notify(100, "Trop bien dormi =^.^=")

    def notify(self, percent, infos):
        print(str(percent) + "%", infos) 





if __name__ == '__main__':
	test = PirusPlugin()
	test.run(None)